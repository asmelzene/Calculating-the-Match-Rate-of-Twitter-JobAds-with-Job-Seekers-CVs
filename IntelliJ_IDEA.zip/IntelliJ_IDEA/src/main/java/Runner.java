public class Runner {
    public static void main(String args[]) throws InterruptedException {
        TwitterKafkaProducer2 twitterKafkaProducer2 = new TwitterKafkaProducer2();
        twitterKafkaProducer2.run();
    }
}
